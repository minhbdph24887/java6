package com.example.demo.bai4.bai4_5_SU_DUNG_RESTTEMPLATE_LAM_VIEC_VOI_RESTFUL_API.bean;

import java.util.HashMap;

public class StudentMap extends HashMap<String, Student> {

}
