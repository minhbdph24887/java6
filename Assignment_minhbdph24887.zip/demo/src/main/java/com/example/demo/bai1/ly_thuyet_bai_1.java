package com.example.demo.bai1;

public class ly_thuyet_bai_1 {
    /*
    * bài 1_2
    * list.stream là cho một stream chứa cả số nguyên
    * filter lọc những số chẵn
    * map chuyển đổi từ kiểu này sang kiểu khác
    * peek kết quả hiện theo như đầu vào truyền đó
    * collect thu thập dữ liệu
    */
}
